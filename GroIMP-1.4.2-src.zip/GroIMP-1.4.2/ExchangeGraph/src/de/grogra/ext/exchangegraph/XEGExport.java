/*
 * Copyright (C) 2002 - 2007 Lehrstuhl Grafische Systeme, BTU Cottbus
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package de.grogra.ext.exchangegraph;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.xmlbeans.XmlOptions;

import de.grogra.ext.exchangegraph.nodes.XEGUnknown;
import de.grogra.ext.exchangegraph.xmlbeans.ExtendsType;
import de.grogra.ext.exchangegraph.xmlbeans.GraphDocument;
import de.grogra.ext.exchangegraph.xmlbeans.Property;
import de.grogra.ext.exchangegraph.xmlbeans.Root;
import de.grogra.graph.Graph;
import de.grogra.graph.impl.Edge;
import de.grogra.graph.impl.Node;
import de.grogra.graph.impl.Node.NType;
import de.grogra.persistence.ManageableType;
import de.grogra.reflect.Reflection;
import de.grogra.xl.util.BidirectionalHashMap;

public class XEGExport {

	private IOContext ctx;
	private Node startNode;

	public XEGExport(Node startNode, IOContext ctx) {

		this.ctx = ctx;
		this.startNode = startNode;
	}

	public String doExport() {
		GraphDocument graphDocument = extractGraph(startNode);

		XmlOptions xmlOptions = new XmlOptions();
		xmlOptions.setSavePrettyPrint();
		xmlOptions.setSavePrettyPrintIndent(2);

		return graphDocument.xmlText(xmlOptions);
	}

	/**
	 * Parse the scene graph and returns new xml graph. Type definition of nodes
	 * are taken from old xml graph.
	 * 
	 * @param rggRoot
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private GraphDocument extractGraph(Node root) {
		GraphDocument graphDocument = GraphDocument.Factory.newInstance();
		de.grogra.ext.exchangegraph.xmlbeans.Graph graph = graphDocument
				.addNewGraph();

		final Set<String> types = new HashSet<String>();
		BidirectionalHashMap<Integer, String> edgeTypes = ctx.getEdgeTypes();
		BidirectionalHashMap<Long, Node> nodeMap = ctx.getNodeMap();
		BidirectionalHashMap<Long, Edge> edgeMap = ctx.getEdgeMap();

		// walk through the graph and find all nodes, will be stored in the set
		final Set<Node> groimpNodes = new HashSet<Node>();
		visitNodes(groimpNodes, root);

		// calculate start node id
		long actNodeId = 0;
		for (Long l : nodeMap.getKeyMap()) {
			if (l > actNodeId)
				actNodeId = l;
		}
		actNodeId++;

		// calculate start edge id
		long actEdgeId = 0;
		for (Long l : edgeMap.getKeyMap()) {
			if (l > actEdgeId)
				actEdgeId = l;
		}
		actEdgeId++;

		// own loop to assign nodes with its corresponding id or a new id
		// important to access when set edges
		for (Node groimpNode : groimpNodes) {
			if (!nodeMap.containsValue(groimpNode)) {
				nodeMap.put(actNodeId++, groimpNode);
			}
		}

		// remove root node and handle it by its own
		groimpNodes.remove(root);
		Root xmlRoot = graph.addNewRoot();
		long rootId = nodeMap.getKey(root) == null ? 0 : nodeMap.getKey(root);
		xmlRoot.setRootId(rootId);

		// now handle every node
		for (Node groimpNode : groimpNodes) {

			// write type to xml document
			String type = writeType(types, groimpNode, graph);

			// write node to xml document
			de.grogra.ext.exchangegraph.xmlbeans.Node xmlNode = graph
					.addNewNode();
			xmlNode.setId(nodeMap.getKey(groimpNode));
			xmlNode.setName(groimpNode.getName());
			xmlNode.setType(type);
			
			
			// write standard node properties
			List<Class> unknownTypes = new ArrayList<Class>(); 
			boolean unknownType = true;
			Class nodeClass = groimpNode.getClass();
			List<Class> handledClasses = new ArrayList<Class>();
			try {
				// loop over hierarchy to set standard properties
				do {
					if (IOContext.xegNodeTypes.containsKey(nodeClass)) {
						Class xegClass = IOContext.xegNodeTypes.get(nodeClass);
						if (!handledClasses.contains(xegClass)) {
							Method m = xegClass.getMethod("handleExportProperties", Node.class, de.grogra.ext.exchangegraph.xmlbeans.Node.class);
							m.invoke(null, groimpNode, xmlNode);
							unknownType = false;
							handledClasses.add(xegClass);
						}
					}
					else {
						if (unknownType)
							unknownTypes.add(nodeClass);
					}
					// continue with superclass
					nodeClass = nodeClass.getSuperclass();
				} while (nodeClass != Object.class);
			} catch (Exception e) {e.printStackTrace();}

			// write unknown property values of the node
			XEGUnknown.handleExportProperties(groimpNode, xmlNode, unknownTypes);

			// write edges to xml document
			for (Edge groimpEdge = groimpNode.getFirstEdge(); groimpEdge != null; groimpEdge = groimpEdge
					.getNext(groimpNode)) {
				if (groimpEdge.getTarget() == groimpNode) {
					long srcId = nodeMap.getKey(groimpEdge.getSource());
					long dstId = nodeMap.getKey(groimpEdge.getTarget());
					long edgeId = edgeMap.containsValue(groimpEdge) ? edgeMap
							.getKey(groimpEdge) : actEdgeId++;

					// write only incoming edges to avoid duplicates
					int edgeBits = groimpEdge.getEdgeBits();

					if ((edgeBits & Graph.SUCCESSOR_EDGE) == Graph.SUCCESSOR_EDGE) {
						de.grogra.ext.exchangegraph.xmlbeans.Edge xmlEdge = graph
								.addNewEdge();
						xmlEdge.setId(edgeId);
						xmlEdge.setSrcId(srcId);
						xmlEdge.setDestId(dstId);
						xmlEdge.setType("successor");
					}
					if ((edgeBits & Graph.BRANCH_EDGE) == Graph.BRANCH_EDGE) {
						de.grogra.ext.exchangegraph.xmlbeans.Edge xmlEdge = graph
								.addNewEdge();
						xmlEdge.setId(edgeId);
						xmlEdge.setSrcId(srcId);
						xmlEdge.setDestId(dstId);
						xmlEdge.setType("branch");
					}
					for (int i = 0; i < 15; i++) {
						if (((edgeBits >> i) & Graph.MIN_UNUSED_EDGE) == Graph.MIN_UNUSED_EDGE) {
							de.grogra.ext.exchangegraph.xmlbeans.Edge xmlEdge = graph
									.addNewEdge();
							xmlEdge.setId(edgeId);
							xmlEdge.setSrcId(srcId);
							xmlEdge.setDestId(dstId);
							String edgeType = edgeTypes.get(i);
							if (edgeType == null)
								edgeType = "EDGE_" + String.valueOf(i);
							xmlEdge.setType(edgeType);
						}
					}
				}
			}
		}

		// graphDocument.validate();
		return graphDocument;
	}

	@SuppressWarnings("unchecked")
	private String writeType(Set<String> types, Node groimpNode,
			de.grogra.ext.exchangegraph.xmlbeans.Graph graph) {

		NType nodeType = groimpNode.getNType();
		Class nodeClass = groimpNode.getClass();

		String type = getTypeForNodeClass(nodeClass);
		String resultType = new String(type);

		// write type to xml document if not already exists
		while (!types.contains(type)) {
			
			// do not add standard node types
			if (IOContext.importNodeTypes.containsKey(type))
				break;

			// add type to xml file
			types.add(type);
			de.grogra.ext.exchangegraph.xmlbeans.Type xmlType = graph
					.addNewType();
			xmlType.setName(type);

			// set properties to type
			int fieldCount = nodeType.getManagedFieldCount();
			for (int i = 0; i < fieldCount; i++) {
				ManageableType.Field mf = nodeType.getManagedField(i);
				if ((mf.getDeclaringType() == nodeType)
						&& (Reflection.isPrimitiveOrString(mf.getType()))) {
					Property xmlProperty = xmlType.addNewProperty();
					xmlProperty.setName(mf.getSimpleName());
					xmlProperty.setType(mf.getType().getSimpleName());
				}
			}

			// find out if super class needs to be written to xml file
			if (!IOContext.exportNodeTypes.containsKey(nodeClass.getName())) {
				ExtendsType extend = xmlType.addNewExtends();
				nodeClass = nodeClass.getSuperclass();
				nodeType = (NType) nodeType.getManageableSupertype();
				type = getTypeForNodeClass(nodeClass);
				extend.setName(type);
			}
		}
		return resultType;
	}

	@SuppressWarnings("unchecked")
	private String getTypeForNodeClass(Class nodeClass) {
		String className = nodeClass.getName();
		if (className.indexOf("$") != -1)
			className = className.substring(className.indexOf("$") + 1);
		String type = IOContext.exportNodeTypes.get(nodeClass.getName());
		if (type == null) {
			type = nodeClass.getSimpleName();
		}
		return type;
	}

	/**
	 * Put node into the set and visit child nodes.
	 * 
	 * @param set
	 * @param node
	 */
	private void visitNodes(Set<Node> set, Node node) {
		if (!set.contains(node)) {
			set.add(node);
			for (Edge edge = node.getFirstEdge(); edge != null; edge = edge
					.getNext(node)) {
				visitNodes(set, edge.getTarget());
			}
		}
	}

}
