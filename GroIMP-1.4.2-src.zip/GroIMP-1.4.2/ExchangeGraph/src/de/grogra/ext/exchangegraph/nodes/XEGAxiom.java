package de.grogra.ext.exchangegraph.nodes;

import java.util.List;
import de.grogra.ext.exchangegraph.xmlbeans.Property;
import de.grogra.graph.impl.Node;

public class XEGAxiom {

	public static void handleImportProperties(Node node, List<Property> properties, List<Property> handledProperties) {
		
	}
	
	public static void handleExportProperties(Node node, de.grogra.ext.exchangegraph.xmlbeans.Node xmlNode) {

	}
	
}
