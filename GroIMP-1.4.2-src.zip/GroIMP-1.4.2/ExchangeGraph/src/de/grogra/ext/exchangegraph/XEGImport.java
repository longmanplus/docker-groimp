/*
 * Copyright (C) 2002 - 2007 Lehrstuhl Grafische Systeme, BTU Cottbus
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package de.grogra.ext.exchangegraph;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.xmlbeans.XmlError;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import de.grogra.ext.exchangegraph.nodes.XEGUnknown;
import de.grogra.ext.exchangegraph.xmlbeans.GraphDocument;
import de.grogra.ext.exchangegraph.xmlbeans.Property;
import de.grogra.grammar.RecognitionException;
import de.grogra.graph.impl.Edge;
import de.grogra.graph.impl.Node;
import de.grogra.pf.io.ReaderSourceImpl;
import de.grogra.pf.registry.Registry;
import de.grogra.reflect.Type;
import de.grogra.rgg.model.CompilationFilter;
import de.grogra.rgg.model.RGGFilter;
import de.grogra.rgg.model.XLFilter;
import de.grogra.util.MimeType;
import de.grogra.xl.util.BidirectionalHashMap;

public class XEGImport {

	private Node rootNode;
	private Reader graphReader;
	private IOContext ctx;
	private String xlCode;
	private String modelName;
	
	private Type<?>[] compiledTypes;

	/**
	 * Constructor called by GroIMP (Object->Insert File).
	 * 
	 * @throws IOException
	 */
	public XEGImport(Reader graphReader, Node rootNode, IOContext ctx, String xlCode, String modelName) {
		this.rootNode = rootNode;
		this.graphReader = graphReader;
		this.ctx = ctx;
		this.xlCode = xlCode;
		this.modelName = modelName;
	}

	public void doImport() throws IOException {
		rootNode.setName("XEGRoot");
		GraphDocument graphDocument = null;

		// parse document and test for errors
		try {
			XmlOptions opt = new XmlOptions();
			opt.setLoadLineNumbers();
			graphDocument = GraphDocument.Factory.parse(graphReader, opt);
		} catch (XmlException e) {
			throw new IOException("XEG parsing error: "
					+ e.getCause().getMessage());
		}
		ArrayList<XmlError> validationErrors = new ArrayList<XmlError>();
		XmlOptions validationOptions = new XmlOptions();
		validationOptions.setErrorListener(validationErrors);
		boolean valid = graphDocument.validate(validationOptions);
		if (!valid) {
			StringBuffer sb = new StringBuffer();
			sb.append("XEG document not valid!");
			for (int i = 0; i < validationErrors.size(); i++) {
				XmlError error = (XmlError) validationErrors.get(i);
				sb.append("\n");
				sb.append("Message: " + error.getMessage());
				sb.append("Location: line "
						+ error.getLine() + "; "
						+ error.getCursorLocation().xmlText() + "\n");
			}
			throw new IOException(sb.toString());
		}

		// copy the graph to the groimp graph
		copyGraph(graphDocument);
	}

	/**
	 * Creates for nodes in xml graph the corresponding GroIMP nodes and puts
	 * them into the scene graph.
	 * 
	 * @param graphDocument
	 */
	@SuppressWarnings("unchecked")
	private void copyGraph(GraphDocument graphDocument) throws IOException {
		// obtain the root element of the xml file
		de.grogra.ext.exchangegraph.xmlbeans.Graph graph = graphDocument
				.getGraph();

		// create groimp node types for type declarations
		HashMap<String, Type> additionalNodeTypes = createGroimpNodeTypes(graph);

		// read all node declarations and put them into a hashmap with id as key
		BidirectionalHashMap<Long, Node> nodeMap = ctx.getNodeMap();
		BidirectionalHashMap<Long, Edge> edgeMap = ctx.getEdgeMap();

		for (de.grogra.ext.exchangegraph.xmlbeans.Node xmlNode : graph
				.getNodeList()) {
			long id = xmlNode.getId();
			String typeName = xmlNode.isSetType() ? xmlNode.getType() : "node";
			Node groimpNode = createGroimpNode(typeName, xmlNode,
					additionalNodeTypes);
			nodeMap.put(id, groimpNode);
		}

		// put rgg root node into hashmap
		long rootId = graph.getRootArray(0).getRootId();
		nodeMap.put(rootId, rootNode);

		// read all edge declarations and connect the nodes according to that
		for (de.grogra.ext.exchangegraph.xmlbeans.Edge xmlEdge : graph
				.getEdgeList()) {
			long srcId = xmlEdge.getSrcId();
			long dstId = xmlEdge.getDestId();
			Node srcNode = nodeMap.get(srcId);
			Node dstNode = nodeMap.get(dstId);
			int edgeBit = getEdgeBit(xmlEdge.getType().toLowerCase());
			Edge e = srcNode.getOrCreateEdgeTo(dstNode);
			e.addEdgeBits(edgeBit, null);
			edgeMap.put(xmlEdge.getId(), e);
		}
	}

	@SuppressWarnings("unchecked")
	private HashMap<String, Type> createGroimpNodeTypes(
			de.grogra.ext.exchangegraph.xmlbeans.Graph graph) {
		// create xl string with node declarations
		StringBuffer newTypesString = new StringBuffer();
		newTypesString.append("import de.grogra.imp3d.objects.*;");
		for (de.grogra.ext.exchangegraph.xmlbeans.Type type : graph
				.getTypeList()) {
			// do not create types for standard node types
			// (types which already exists in groimp)
			if (IOContext.importNodeTypes.containsKey(type.getName()))
				continue;

			newTypesString.append("public class ");
			newTypesString.append(type.getName());
			newTypesString.append(" extends ");
			String extendType = type.getExtends().getName();
			newTypesString.append(IOContext.importNodeTypes
					.containsKey(extendType) ? IOContext.importNodeTypes
					.get(extendType) : extendType);
			newTypesString.append("{");
			for (Property property : type.getPropertyList()) {
				newTypesString.append(property.getType() + " "
						+ property.getName() + ";");
			}
			newTypesString.append("};");
		}
		// compile xl string to get types
		try {
			XLFilter xlFilter = new XLFilter (null, new ReaderSourceImpl (new StringReader(newTypesString
					.toString()), "XEGNodeTypes", MimeType.TEXT_PLAIN, Registry.current (), null));
			
			CompilationFilter compilationFilter = new CompilationFilter (null, xlFilter);
			
			// compile optional xl code
			if (xlCode != null) {
				RGGFilter rggFilter = new RGGFilter(null, new ReaderSourceImpl(
						new StringReader(xlCode), modelName, MimeType.TEXT_PLAIN, Registry
								.current(), null));
				compilationFilter.addResource(rggFilter);
			}
			
			compiledTypes = compilationFilter.compile(null, null);			
		} catch (IOException e) {
			if (e.getCause() instanceof RecognitionException)
				System.err.println(((RecognitionException) e.getCause())
						.getDetailedMessage(false));
		} catch (Exception e) {
			System.err.println(e.getCause());
		}
		// create hashmap for xge type names and groimp types
		HashMap<String, Type> additionalNodeTypes = new HashMap<String, Type>();
		for (Type compiledType : compiledTypes) {
			// do not use getSimpleName, instead use getName without modelName
			String typeName = compiledType.getName();
			if ((modelName != null) && typeName.startsWith(modelName) && (typeName.length() > modelName.length()))
				typeName = typeName.substring(modelName.length() + 1, typeName.length());
			additionalNodeTypes.put(typeName, compiledType);
		}
		return additionalNodeTypes;
	}

	/**
	 * Creates GroIMP nodes for specified type.
	 * 
	 * @param typeName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Node createGroimpNode(String typeName,
			de.grogra.ext.exchangegraph.xmlbeans.Node xmlNode,
			HashMap<String, Type> additionalNodeTypes) throws IOException {

		Node node = null;

		// create instance
		try {
			if (IOContext.importNodeTypes.containsKey(typeName)) {
				node = (Node) Class.forName(
						IOContext.importNodeTypes.get(typeName)).newInstance();
			} else {
				node = (Node) additionalNodeTypes.get(typeName)
						.newInstance();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// set properties
		List<Property> properties = xmlNode.getPropertyList();
		List<Property> handledProperties = new ArrayList<Property>(properties
				.size());
		Class nodeClass = node.getClass();

		try {
			// loop over hierarchy to set standard properties
			do {
				if (IOContext.xegNodeTypes.containsKey(nodeClass)) {
					Class xegClass = IOContext.xegNodeTypes.get(nodeClass);
					Method m = xegClass.getMethod("handleImportProperties",
							Node.class, List.class, List.class);
					m.invoke(null, node, properties, handledProperties);

					// remove set attributes
					for (Property p : handledProperties)
						properties.remove(p);
					handledProperties.clear();
				}
				// continue with superclass
				nodeClass = nodeClass.getSuperclass();
			} while (nodeClass != Object.class);

			// now set unknown properties (the rest in die properties list)
			XEGUnknown.handleImportProperties(node, properties);
		} catch (Exception e) {
			throw new IOException("Couldn't create GroIMP node: " + e.getMessage());
		}

		// set name
		if (xmlNode.isSetName()	&& (!xmlNode.getName().trim().equals("")))
			node.setName(xmlNode.getName());

		return node;
	}

	/**
	 * Returns the GroIMP specific edge bits for a given xml edge type.
	 * 
	 * @param type
	 * @return
	 */
	private int getEdgeBit(String type) {
		BidirectionalHashMap<Integer, String> edgeTypes = ctx.getEdgeTypes();

		if ("successor".equals(type))
			return de.grogra.graph.Graph.SUCCESSOR_EDGE;
		if ("branch".equals(type))
			return de.grogra.graph.Graph.BRANCH_EDGE;
		if (edgeTypes.containsValue(type)) {
			return edgeTypes.getKey(type);
		} else {
			int minEdge = edgeTypes.size();
			edgeTypes.put(minEdge, type);
			return de.grogra.graph.Graph.MIN_UNUSED_EDGE << minEdge;
		}
	}

	public Node getRootNode() {
		return rootNode;
	}

	public Type<?>[] getCompiledTypes() {
		return compiledTypes;
	}
}
