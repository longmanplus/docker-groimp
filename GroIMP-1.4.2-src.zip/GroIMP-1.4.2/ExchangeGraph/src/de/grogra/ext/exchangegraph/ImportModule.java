
/*
 * Copyright (C) 2002 - 2007 Lehrstuhl Grafische Systeme, BTU Cottbus
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package de.grogra.ext.exchangegraph;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import de.grogra.graph.impl.Node;
import de.grogra.pf.io.FilterBase;
import de.grogra.pf.io.FilterItem;
import de.grogra.pf.io.FilterSource;
import de.grogra.pf.io.IOFlavor;
import de.grogra.pf.io.ObjectSource;

public class ImportModule extends FilterBase implements ObjectSource {

	private Node rootNode = null;

	public ImportModule(FilterItem item, FilterSource source)  {
		super(item, source);
		setFlavor(IOFlavor.valueOf(Node.class));
	}
	
	public Object getObject() throws IOException {
		IOContext ctx = new IOContext();
		
		File file = new File(source.getSystemId());
		FileReader fr = new FileReader(file);
		
		rootNode = new Node();
		XEGImport importer = new XEGImport(fr, rootNode, ctx, null, null);
		importer.doImport();
	
		return rootNode;
	}

}
