package de.grogra.ext.exchangegraph.nodes;

import java.util.ArrayList;
import java.util.List;
import de.grogra.ext.exchangegraph.xmlbeans.Property;
import de.grogra.graph.impl.Node;
import de.grogra.imp3d.objects.MeshNode;
import de.grogra.imp3d.objects.PolygonMesh;
import de.grogra.xl.util.FloatList;
import de.grogra.xl.util.IntList;

public class XEGMeshNode {

	@SuppressWarnings("unchecked")
	public static void handleImportProperties(Node node, List<Property> properties, List<Property> handledProperties) {
		
		List<Integer> indices = null;
		List<Float> coords = null;
		List<Float> normals = null;
		
		for (Property p : properties) {
			if (p.getName().equals("indices")) {
				indices = p.getListOfInt();
				handledProperties.add(p);
			}
			else if (p.getName().equals("coords")) {
				coords = p.getListOfFloat();
				handledProperties.add(p);
			}
			else if (p.getName().equals("normals")) {
				normals =p.getListOfFloat();
				handledProperties.add(p);
			}
		}
		
		createMeshNode((MeshNode) node, indices, coords, normals);
		
	}

	public static void handleExportProperties(Node node, de.grogra.ext.exchangegraph.xmlbeans.Node xmlNode) {
		
		PolygonMesh p = null;		
		if (((MeshNode) node).getPolygons() instanceof PolygonMesh)
			p = (PolygonMesh) ((MeshNode) node).getPolygons();

		if (p == null)
			return;
		
		Property xmlProperty = xmlNode.addNewProperty();
		xmlProperty.setName("indices");
		int[] indexArray = p.getIndexData();
		ArrayList<Integer> indexList = new ArrayList<Integer>(indexArray.length);
		for (int i : indexArray)
			indexList.add(i);
		xmlProperty.setListOfInt(indexList);
		
		xmlProperty = xmlNode.addNewProperty();
		xmlProperty.setName("coords");
		float[] coordArray = p.getVertexData();
		ArrayList<Float> coordList = new ArrayList<Float>(coordArray.length);
		for (float f : coordArray)
			coordList.add(f);
		xmlProperty.setListOfFloat(coordList);

		if (p.getNormalData() != null) {
			xmlProperty = xmlNode.addNewProperty();
			xmlProperty.setName("normals");
			float[] normalArray = p.getNormalData();
			ArrayList<Float> normalList = new ArrayList<Float>(normalArray.length);
			for (float f : normalArray)
				normalList.add(f);
			xmlProperty.setListOfFloat(normalList);
		}
	}
	
	public static void createMeshNode(MeshNode node, List<Integer> indices,
			List<Float> coords, List<Float> normals) {
		
		PolygonMesh p = new PolygonMesh();
		
		IntList indexList = new IntList(indices.size());
		for (Integer i : indices)
			indexList.add(i);
		p.setIndexData(indexList);
		
		FloatList coordList = new FloatList(coords.size());
		for (Float f : coords)
			coordList.add(f);
		p.setVertexData(coordList);
		
		if (normals != null) {
			FloatList normalList = new FloatList(normals.size());
			for (Float f : normals)
				normalList.add(f);
			p.setNormalData(normalList.elements);
		}
				
		node.setPolygons(p);
		
	}
	
}
