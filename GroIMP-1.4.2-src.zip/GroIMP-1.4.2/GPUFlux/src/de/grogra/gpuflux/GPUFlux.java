package de.grogra.gpuflux;

import de.grogra.pf.registry.Plugin;
import de.grogra.util.I18NBundle;

public class GPUFlux extends Plugin
{
	public static final I18NBundle I18N = I18NBundle.getInstance (GPUFlux.class);
	
	public boolean initialize ()
	{
		return true;
	}
		
}
