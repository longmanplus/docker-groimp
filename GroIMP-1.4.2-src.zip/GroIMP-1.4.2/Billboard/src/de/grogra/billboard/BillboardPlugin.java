package de.grogra.billboard;

import de.grogra.pf.registry.Plugin;

public class BillboardPlugin extends Plugin {

}

