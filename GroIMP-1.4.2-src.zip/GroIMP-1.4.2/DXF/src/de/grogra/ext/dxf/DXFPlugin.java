package de.grogra.ext.dxf;

import de.grogra.pf.registry.Plugin;

public class DXFPlugin extends Plugin
{

}
